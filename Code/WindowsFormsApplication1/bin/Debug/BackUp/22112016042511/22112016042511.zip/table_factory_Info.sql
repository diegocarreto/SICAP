INSERT INTO [dbo].[factory]([id],[name],[active],[deleted],[createDate],[updateDate],[deletedDate]) Values( '1','Tlapalería San Jorge','1','0','Jul 16 2016 10:43AM',Null,Null)
INSERT INTO [dbo].[factory]([id],[name],[active],[deleted],[createDate],[updateDate],[deletedDate]) Values( '2','Materiales San Jorge','1','0','Jul 16 2016 10:44AM',Null,Null)
