create table [configuration] (
  [key] varchar(50)  NOT NULL ,
  [value] varchar(8000)  NOT NULL 
)
