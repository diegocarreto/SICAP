INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '1','5512293375','999916','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5512293375
folio:999916
monto:10

realizar nueva recarga','Apr  9 2016  4:27PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2','7841362690','180419','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:7841362690
folio:180419
monto:50

realizar nueva recarga','Apr 23 2016 11:26AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3','5591018233','047272','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:047272
monto:100

realizar nueva recarga','Apr 23 2016  1:44PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '4','5514317322','488226','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5514317322
folio:488226
monto:10

realizar nueva recarga','Apr 28 2016  2:07PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5','5542375397','366108','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542375397
folio:366108
monto:50

realizar nueva recarga','Apr 29 2016  9:27AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '6','5540921741','851168','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:851168
monto:30

realizar nueva recarga','Apr 29 2016 10:50AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '1004','5512293375','122814','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512293375
folio:122814
monto:50

realizar nueva recarga','Apr 30 2016  3:59PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2004','5585414824','771699','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5585414824
folio:771699
monto:30

realizar nueva recarga','May  2 2016 12:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2005','5510928175','Error','Unefon','30','31.00','0','su sesión ha expirado, por favor inicie sesión aquí','May  2 2016  6:13PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2006','5510928175','791064','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:791064
monto:30

realizar nueva recarga','May  2 2016  6:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2007','2821098433','164924','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:2821098433
folio:164924
monto:30

realizar nueva recarga','May  3 2016  9:50AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2008','5515696136','Error','Unefon','50','51.00','0','su sesión ha expirado, por favor inicie sesión aquí','May  3 2016  4:55PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2009','5515696136','837390','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5515696136
folio:837390
monto:50

realizar nueva recarga','May  3 2016  4:59PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2010','5540921741','998892','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:998892
monto:30

realizar nueva recarga','May  4 2016  5:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2011','5515259839','460461','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5515259839
folio:460461
monto:20

realizar nueva recarga','May  5 2016 11:29AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2012','5573028540','919590','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5573028540
folio:919590
monto:50

realizar nueva recarga','May  5 2016  4:50PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2015','5541921741','Error','Telcel','30','31.00','0','error en recarga:99 - sin saldo suficiente (5.00). requerido 30.00','May  5 2016  5:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2018','1111111111','123455','Movistar','10','11.00','1','Recarga realizada por otro medio','May  5 2016 11:08PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2019','1111111111','54321','Telcel','10','11.00','1','Recarga realizada por otro medio','May  5 2016 11:09PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2020','5525217192','169599','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5525217192
folio:169599
monto:50

realizar nueva recarga','May  6 2016  1:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3020','5533135792','511307','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5533135792
folio:511307
monto:30

realizar nueva recarga','May  6 2016  2:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3021','5546533516','704828','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5546533516
folio:704828
monto:30

realizar nueva recarga','May  6 2016  5:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3022','5533951549','36610588','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5533951549
folio:36610588
monto:20

realizar nueva recarga','May  7 2016 10:41AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3023','5591018233','030227','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:030227
monto:100

realizar nueva recarga','May  7 2016  2:05PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3025','5530524327','892386','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5530524327
folio:892386
monto:30

realizar nueva recarga','May  9 2016  9:34AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3026','5533079301','916858','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5533079301
folio:916858
monto:50

realizar nueva recarga','May  9 2016  5:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3027','5512293375','207425','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512293375
folio:207425
monto:50

realizar nueva recarga','May 12 2016  3:50PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3030','5523994735','783795','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5523994735
folio:783795
monto:10

realizar nueva recarga','May 13 2016  4:28PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3031','5510928175','402151','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:402151
monto:30

realizar nueva recarga','May 14 2016 12:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3032','5512404104','767988','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:767988
monto:50

realizar nueva recarga','May 17 2016 12:13PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3033','5572727712','983395','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:983395
monto:50

realizar nueva recarga','May 17 2016 12:15PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3034','5520581751','187324','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5520581751
folio:187324
monto:50

realizar nueva recarga','May 17 2016 12:18PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3036','5546832821','342402','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:342402
monto:50

realizar nueva recarga','May 17 2016 12:21PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3038','5515218125','858120','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5515218125
folio:858120
monto:50

realizar nueva recarga','May 17 2016 12:25PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3039','5516036030','529976','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5516036030
folio:529976
monto:100

realizar nueva recarga','May 17 2016  4:33PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '4032','5538750407','751138','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5538750407
folio:751138
monto:50

realizar nueva recarga','May 18 2016  5:21PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '4033','5510928175','651814','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:651814
monto:30

realizar nueva recarga','May 18 2016  5:52PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5032','5568043071','460081','Iusacell','30','31.00','1','resultado:recarga exitosa
teléfono:5568043071
folio:460081
monto:30

realizar nueva recarga','May 20 2016  9:48AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5033','5551652775','460176','Iusacell','30','31.00','1','resultado:recarga exitosa
teléfono:5551652775
folio:460176
monto:30

realizar nueva recarga','May 20 2016  9:50AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5035','5540921741','575958','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:575958
monto:30

realizar nueva recarga','May 20 2016  2:20PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5036','5550303253','787250','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5550303253
folio:787250
monto:100

realizar nueva recarga','May 21 2016 12:14PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5037','5532159017','787796','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5532159017
folio:787796
monto:50

realizar nueva recarga','May 21 2016 12:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5039','5591018233','802244','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:802244
monto:50

realizar nueva recarga','May 21 2016  3:19PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5040','5518356106','536004','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5518356106
folio:536004
monto:30

realizar nueva recarga','May 23 2016 10:50AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5041','5518597919','Error','Movistar','20','21.00','0','su sesión ha expirado, por favor inicie sesión aquí','May 23 2016  5:42PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5043','5516342899','37166791','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5516342899
folio:37166791
monto:50

realizar nueva recarga','May 23 2016  5:48PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5044','2821098433','979002','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:2821098433
folio:979002
monto:30

realizar nueva recarga','May 24 2016  2:26PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5046','5533212386','843602','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5533212386
folio:843602
monto:20

realizar nueva recarga','May 25 2016  8:38AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '6046','5569870176','119934','Virgin','50','51.00','1','resultado:recarga exitosa
teléfono:5569870176
folio:119934
monto:50

realizar nueva recarga','May 25 2016  9:20AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2013','5516342899','939817','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5516342899
folio:939817
monto:50

realizar nueva recarga','May  5 2016  5:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2014','5591018233','934108','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:934108
monto:50

realizar nueva recarga','May  5 2016  5:19PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2016','5541921741','964690','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5541921741
folio:964690
monto:30

realizar nueva recarga','May  5 2016  5:23PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3035','5542242858','780856','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542242858
folio:780856
monto:50

realizar nueva recarga','May 17 2016 12:19PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5034','5540921741','Error','Telcel','30','31.00','0','su sesión ha expirado, por favor inicie sesión aquí','May 20 2016  2:19PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5038','5515765170','10328','Telcel','50','51.00','1','Recarga realizada por otro medio','May 21 2016  1:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5042','5518597919','37164685','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:37164685
monto:20

realizar nueva recarga','May 23 2016  5:43PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '5045','5536389362','967464','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5536389362
folio:967464
monto:50

realizar nueva recarga','May 24 2016  6:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '6047','5545518708','874005','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5545518708
folio:874005
monto:50

realizar nueva recarga','May 25 2016 11:06AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '6048','5518356106','182978','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5518356106
folio:182978
monto:30

realizar nueva recarga','May 25 2016  6:29PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '6049','5540921741','705647','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:705647
monto:30

realizar nueva recarga','May 27 2016  3:07PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '6050','5523637850','753402','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5523637850
folio:753402
monto:50

realizar nueva recarga','May 28 2016 10:12AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7050','2741119117','256536','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:2741119117
folio:256536
monto:50

realizar nueva recarga','May 30 2016  8:29AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7051','5512293375','210860','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512293375
folio:210860
monto:50

realizar nueva recarga','May 30 2016  8:46PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7052','5533212386','922283','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5533212386
folio:922283
monto:20

realizar nueva recarga','Jun  1 2016  8:28AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7054','5511887316','318415','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5511887316
folio:318415
monto:20

realizar nueva recarga','Jun  2 2016  2:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7055','5515696136','453830','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5515696136
folio:453830
monto:50

realizar nueva recarga','Jun  2 2016  5:14PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7056','5516342899','37471603','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5516342899
folio:37471603
monto:50

realizar nueva recarga','Jun  2 2016  5:24PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7061','5540921741','864462','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:864462
monto:50

realizar nueva recarga','Jun  4 2016  9:08AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7062','5548098456','092267','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5548098456
folio:092267
monto:100

realizar nueva recarga','Jun  7 2016  9:43AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7063','5563436343','021928','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5563436343
folio:021928
monto:50

realizar nueva recarga','Jun  8 2016  8:48AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7064','5563747505','756189','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5563747505
folio:756189
monto:30

realizar nueva recarga','Jun  8 2016 10:47AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7065','7223155257','818192','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:7223155257
folio:818192
monto:100

realizar nueva recarga','Jun  9 2016  1:44PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7066','2281172239','823198','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:823198
monto:50

realizar nueva recarga','Jun  9 2016  3:26PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7067','5540522312','366625','Telcel','500','501.00','1','resultado:recarga exitosa
teléfono:5540522312
folio:366625
monto:500

realizar nueva recarga','Jun 10 2016  9:33AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7068','5514317322','37903990','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5514317322
folio:37903990
monto:20

realizar nueva recarga','Jun 13 2016 12:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7070','5563436343','12562','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5563436343
folio:12562
monto:100

realizar nueva recarga','Jun 14 2016  9:35AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8062','5516342899','26252','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5516342899
folio:26252
monto:50

realizar nueva recarga','Jun 14 2016  5:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8065','5510941353','430991','Movistar','200','201.00','1','resultado:recarga exitosa
teléfono:5510941353
folio:430991
monto:200

realizar nueva recarga','Jun 15 2016  5:43PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9062','5533135792','652251','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5533135792
folio:652251
monto:10

realizar nueva recarga','Jun 21 2016  8:44AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9063','5540388591','691677','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540388591
folio:691677
monto:30

realizar nueva recarga','Jun 21 2016 10:53AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9065','5542242858','403539','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542242858
folio:403539
monto:50

realizar nueva recarga','Jun 21 2016 11:25AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9066','5515218125','587599','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5515218125
folio:587599
monto:50

realizar nueva recarga','Jun 21 2016 11:29AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9067','5546832821','872177','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:872177
monto:50

realizar nueva recarga','Jun 21 2016 11:48AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9069','5520581751','244633','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5520581751
folio:244633
monto:50

realizar nueva recarga','Jun 21 2016 12:20PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9071','5533968498','689943','Movistar','40','41.00','1','resultado:recarga exitosa
teléfono:5533968498
folio:689943
monto:40

realizar nueva recarga','Jun 21 2016  2:56PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9072','5511887316','529364','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5511887316
folio:529364
monto:20

realizar nueva recarga','Jun 22 2016 10:40AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9073','5538566029','38268558','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:38268558
monto:50

realizar nueva recarga','Jun 22 2016 10:49AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9075','5510928175','540925','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:540925
monto:50

realizar nueva recarga','Jun 22 2016  5:53PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9076','5516342899','544174','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5516342899
folio:544174
monto:50

realizar nueva recarga','Jun 23 2016  5:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9078','5510928175','682547','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:682547
monto:50

realizar nueva recarga','Jun 25 2016  1:56PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9081','5519536471','979890','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5519536471
folio:979890
monto:30

realizar nueva recarga','Jun 27 2016  8:05AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9086','5563190148','Error','Movistar','10','11.00','0','error en recarga: referencia no valida / revisar operador','Jun 28 2016  6:37PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9087','5563190148','Error','Telcel','10','11.00','0','error en recarga:99 - error al realizar recarga: numero de telefono invalido - fi: 2726115','Jun 28 2016  6:39PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9088','5563190148','854730','Unefon','10','11.00','1','resultado:recarga exitosa
teléfono:5563190148
folio:854730
monto:10

realizar nueva recarga','Jun 28 2016  6:42PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9089','5518959883','38611992','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5518959883
folio:38611992
monto:100


realizar nueva recarga','Jun 29 2016  8:13PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9090','5533212386','412005','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5533212386
folio:412005
monto:30

realizar nueva recarga','Jun 30 2016 10:10AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9091','5519536471','38623770','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5519536471
folio:38623770
monto:20

realizar nueva recarga','Jun 30 2016 11:44AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '2017','5540921741','591992','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:591992
monto:20

realizar nueva recarga','May  5 2016  5:38PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7053','5591018233','438880','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:438880
monto:50

realizar nueva recarga','Jun  2 2016  1:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8066','5539321115','893515','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5539321115
folio:893515
monto:100

realizar nueva recarga','Jun 16 2016  1:53PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9064','5572727712','193168','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:193168
monto:50

realizar nueva recarga','Jun 21 2016 11:14AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9092','5548478438','38625910','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5548478438
folio:38625910
monto:50

realizar nueva recarga','Jun 30 2016 12:33PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9093','5563341064','Error','Movistar','30','31.00','0','su sesión ha expirado, por favor inicie sesión aquí','Jun 30 2016  5:47PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9094','5563341064','38639036','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5563341064
folio:38639036
monto:30

realizar nueva recarga','Jun 30 2016  6:04PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9096','5515765170','710686','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5515765170
folio:710686
monto:50

realizar nueva recarga','Jul  1 2016  9:52AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9097','5574351271','433022','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5574351271
folio:433022
monto:100

realizar nueva recarga','Jul  1 2016 11:18AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9098','5533212386','549200','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5533212386
folio:549200
monto:10

realizar nueva recarga','Jul  1 2016 12:15PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9099','5519536471','38671065','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5519536471
folio:38671065
monto:30

realizar nueva recarga','Jul  1 2016  2:25PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9102','5510501737','224925','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5510501737
folio:224925
monto:100



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  5 2016 10:15AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9103','5538750407','Error','Telcel','50','51.00','0','su sesión ha expirado, por favor inicie sesión aquí','Jul  5 2016  3:01PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9104','5538750407','566471','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5538750407
folio:566471
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  5 2016  3:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9105','5563686355','278356','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5563686355
folio:278356
monto:100



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  6 2016 10:42AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9106','5520581751','771695','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5520581751
folio:771695
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  6 2016  2:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '10102','5518597917','Error','Movistar','20','21.00','0','error en recarga: no se puede abonar','Jul  7 2016  6:29PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11102','5561514770','196922','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5561514770
folio:196922
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  8 2016  5:05PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11104','2224737104','871376','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:2224737104
folio:871376



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 

realizar nueva recarga','Jul  9 2016  9:38AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11105','5510928175','453302','Unefon','30','31.00','1','Recarga realizada por otro medio','Jul  9 2016  2:41PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11106','5591018233','593841','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:593841
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 12 2016  8:32AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11112','5538566029','39216569','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:39216569
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 14 2016  9:10AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12105','5539321115','694602','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5539321115
folio:694602
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Jul 15 2016  2:38PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12110','5518597919','Error','Movistar','20','21.00','0','su sesión ha expirado, por favor inicie sesión aquí','Jul 18 2016  5:07PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12111','5518597919','39400744','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:39400744
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 18 2016  5:11PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12112','5591018233','985648','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:985648
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 18 2016  6:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12113','5572727712','518745','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:518745
monto:50



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Jul 18 2016  9:14PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12116','5529298104','102957','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5529298104
folio:102957
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 20 2016  7:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12117','5566209165','112504','Iusacell','20','21.00','1','resultado:recarga exitosa
teléfono:5566209165
folio:112504
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 21 2016  9:39AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12118','5591018233','185520','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:185520
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 22 2016  2:53PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12122','5510928175','238459','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:238459
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Jul 23 2016  2:00PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3024','5540921741','179627','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:179627
monto:30

realizar nueva recarga','May  7 2016  2:47PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3029','2281172239','315112','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:315112
monto:50

realizar nueva recarga','May 12 2016  6:11PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7069','5585414824','029978','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5585414824
folio:029978
monto:30

realizar nueva recarga','Jun 13 2016  1:36PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8064','5525976219','969316','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5525976219
folio:969316
monto:50

realizar nueva recarga','Jun 15 2016  5:00PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11103','5959528670','018422','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5959528670
folio:018422
monto:20



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 

realizar nueva recarga','Jul  9 2016  9:37AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11107','5534924689','909349','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5534924689
folio:909349
monto:30



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 12 2016  8:41AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12106','5539590028','819553','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5539590028
folio:819553
monto:100



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Jul 16 2016 10:24AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12119','5575477821','39543058','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:39543058
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 22 2016  3:05PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12121','5521536305','953149','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5521536305
folio:953149
monto:100



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Jul 23 2016 11:12AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12123','5512404104','650785','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:650785
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Jul 25 2016  8:47AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12124','5529297607','409517','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5529297607
folio:409517
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 26 2016  2:28PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12126','5538566029','39724744','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:39724744
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 26 2016  5:37PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12128','5538750407','748663','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5538750407
folio:748663
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Jul 27 2016  5:39PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12129','5542610393','226259','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5542610393
folio:226259
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 28 2016  2:44PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12131','5514647493','aaabjy','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5514647493
folio:aaabjy
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 29 2016  9:02AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12133','5575477821','aabkyj','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:aabkyj
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 29 2016  5:46PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12134','5515696136','637743','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5515696136
folio:637743
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 30 2016  2:09PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12135','5516342899','aabarz','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5516342899
folio:aabarz
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  1 2016  2:40PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12136','5591018233','774689','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:774689
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  1 2016  5:29PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13123','5540921741','118398','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:118398
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug  3 2016  1:00PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13124','5528271289','aaaqoa','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5528271289
folio:aaaqoa
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  3 2016  1:29PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13127','5563436343','819651','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5563436343
folio:819651
monto:50



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Aug  4 2016  9:07AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13129','5575486910','816988','Telcel','Sin límite 100 |300 MB| SMS, Llamadas ilimitado, Redes Sociales 1000 MB| Vigencia 25 días','101.00','1','resultado:recarga exitosa
teléfono:5575486910
folio:816988
monto:100



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Aug  6 2016  8:33AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13130','5569870176','119934','Virgin','50','51.00','1','resultado:recarga exitosa
teléfono:5569870176
folio:119934
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  6 2016 10:28AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13134','5518597919','Error','Telcel','20','21.00','0','error en recarga:99 - referencia no valida / revisar operador - fi:81848483','Aug 10 2016  8:20AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13137','5562490198','aaadmg','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5562490198
folio:aaadmg
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 11 2016  9:47AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13138','5515696136','335547','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5515696136
folio:335547
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 11 2016  1:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13139','5568173789','Error','Iusacell','100','101.00','0','su sesión ha expirado, por favor inicie sesión aquí','Aug 12 2016 10:13AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3028','5564173305','314966','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5564173305
folio:314966
monto:30

realizar nueva recarga','May 12 2016  6:08PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3040','5573028540','569246','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5573028540
folio:569246
monto:50

realizar nueva recarga','May 17 2016  6:29PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8067','5591018233','236460','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:236460
monto:50

realizar nueva recarga','Jun 17 2016  9:36AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8068','5515696136','251842','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5515696136
folio:251842
monto:50

realizar nueva recarga','Jun 17 2016  1:53PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9079','5519536471','38421596','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5519536471
folio:38421596
monto:20

realizar nueva recarga','Jun 25 2016  1:58PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12120','5510928175','186441','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:186441
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 22 2016  3:06PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13125','5546832821','527615','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:527615
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug  3 2016  1:37PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13131','5575486910','679828','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5575486910
folio:679828
monto:10



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Aug  6 2016 11:05AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13133','5542242858','805061','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542242858
folio:805061
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug  9 2016  8:24AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13140','5568173789','378943','Iusacell','100','101.00','1','resultado:recarga exitosa
teléfono:5568173789
folio:378943
monto:100



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 12 2016 10:17AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13141','5528230497','903363','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5528230497
folio:903363
monto:20



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Aug 15 2016  8:55AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13142','5547034406','221447','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5547034406
folio:221447
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 15 2016  3:45PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13147','5510928175','790316','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:790316
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 19 2016 10:51AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13150','2821021122','Error','Movistar','50','51.00','0','su sesión ha expirado, por favor inicie sesión aquí','Aug 20 2016  3:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13152','5523637850','40880951','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5523637850
folio:40880951
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 23 2016 10:34AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13153','5516966580','347293','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5516966580
folio:347293
monto:50



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Aug 23 2016 12:48PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13155','5575477821','Error','Movistar','100','101.00','0','su sesión ha expirado, por favor inicie sesión aquí','Aug 24 2016  9:07AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13157','5572727712','723457','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:723457
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 24 2016 12:21PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13158','7491050360','327389','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:7491050360
folio:327389
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 24 2016 12:43PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14147','5530706186','508316','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5530706186
folio:508316
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 26 2016 11:33AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14148','5563686355','263606','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5563686355
folio:263606
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 27 2016  8:32AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14150','5510928175','287835','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:287835
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 27 2016  2:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14153','5533135792','41128165','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5533135792
folio:41128165
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 29 2016  5:28PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14154','5518959883','41130533','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5518959883
folio:41130533
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 29 2016  6:11PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14156','5512404104','Error','Telcel','50','51.00','0','su sesión ha expirado, por favor inicie sesión aquí','Aug 30 2016  4:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14159','5575515346','41165420','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575515346
folio:41165420
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 30 2016  4:51PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14161','5533244124','41185500','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5533244124
folio:41185500
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 31 2016 10:19AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15147','5514317322','987703','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5514317322
folio:987703
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep  1 2016 12:43PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15148','5568173789','603129','Iusacell','100','101.00','1','resultado:recarga exitosa
teléfono:5568173789
folio:603129
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep  1 2016  2:07PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15149','5510941353','aaavui','Movistar','300','301.00','1','resultado:recarga exitosa
teléfono:5510941353
folio:aaavui
monto:300



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep  1 2016  4:32PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '3037','5528230497','500591','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5528230497
folio:500591
monto:50

realizar nueva recarga','May 17 2016 12:24PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '4034','5515696136','651938','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5515696136
folio:651938
monto:50

realizar nueva recarga','May 18 2016  6:15PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8063','5563190148','Error','Iusacell','100','101.00','0','su sesión ha expirado, por favor inicie sesión aquí','Jun 15 2016  9:58AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9074','5510928175','Error','Unefon','50','51.00','0','su sesión ha expirado, por favor inicie sesión aquí','Jun 22 2016  5:47PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9077','5533202883','285118','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5533202883
folio:285118
monto:10

realizar nueva recarga','Jun 25 2016  1:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9082','5569870176','119934','Virgin','50','51.00','1','resultado:recarga exitosa
teléfono:5569870176
folio:119934
monto:50

realizar nueva recarga','Jun 27 2016  9:38AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9083','5542598044','38526127','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5542598044
folio:38526127
monto:50

realizar nueva recarga','Jun 27 2016  5:20PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9084','5534573065','115647','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5534573065
folio:115647
monto:50

realizar nueva recarga','Jun 28 2016  9:03AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9085','5519536471','38544650','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5519536471
folio:38544650
monto:20

realizar nueva recarga','Jun 28 2016  9:11AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11108','5547151609','39154726','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5547151609
folio:39154726
monto:30



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 12 2016 10:13AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11113','5528230497','134352','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5528230497
folio:134352
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 14 2016 10:20AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12107','5585512536','848731','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5585512536
folio:848731
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Jul 16 2016  2:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12125','2281172239','415810','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:415810
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Jul 26 2016  4:00PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13148','5531560997','40736785','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5531560997
folio:40736785
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 20 2016  9:02AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13151','2821021122','40763403','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:2821021122
folio:40763403
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 20 2016  3:24PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14152','5538566029','69980','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:69980
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 29 2016  9:36AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14155','5547034406','330265','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5547034406
folio:330265
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 30 2016  9:47AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14157','5512404104','711595','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:711595
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 30 2016  4:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14158','5573959302','365508','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5573959302
folio:365508
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 30 2016  4:34PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14162','5570710433','41193943','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5570710433
folio:41193943
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 31 2016  2:18PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15151','5574140137','630554','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5574140137
folio:630554
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep  5 2016 10:50AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15153','5562190923','616168','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5562190923
folio:616168
monto:100



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep  5 2016 12:25PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15154','5510928175','831139','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:831139
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep  5 2016  1:04PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15155','5540921741','995748','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:995748
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep  5 2016  4:28PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15156','5563436343','732932','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5563436343
folio:732932
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep  7 2016  9:31AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15158','5538566029','aaayva','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:aaayva
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep  9 2016  3:46PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15159','5575477821','aaaqsq','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:aaaqsq
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 10 2016  1:54PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '16149','5566268748','373955','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5566268748
folio:373955
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 14 2016  4:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17149','5571444636','aaadfy','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5571444636
folio:aaadfy
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Sep 17 2016  9:53AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7057','5529877280','37490702','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5529877280
folio:37490702
monto:50

realizar nueva recarga','Jun  3 2016  9:51AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7058','5529840729','37492994','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5529840729
folio:37492994
monto:20

realizar nueva recarga','Jun  3 2016 10:53AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7059','5562490198','37493813','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5562490198
folio:37493813
monto:20

realizar nueva recarga','Jun  3 2016 10:58AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '7060','5538837557','698599','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5538837557
folio:698599
monto:50

realizar nueva recarga','Jun  3 2016 12:37PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9095','2281172239','971085','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:971085
monto:50

realizar nueva recarga','Jun 30 2016  6:07PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13126','5518597919','aaayji','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:aaayji
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  3 2016  4:13PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14149','5573959302','280539','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5573959302
folio:280539
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 27 2016 12:24PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14160','5533244124','Error','Movistar','30','31.00','0','su sesión ha expirado, por favor inicie sesión aquí','Aug 31 2016 10:18AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15152','5534394754','14049','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5534394754
folio:14049
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep  5 2016 12:15PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15157','5512404104','082767','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:082767
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep  8 2016  2:09PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '16147','5542242858','113700','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542242858
folio:113700
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 12 2016 11:26AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '16148','5546832821','841094','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:841094
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 14 2016  1:44PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17147','5574140137','801626','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5574140137
folio:801626
monto:30



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 15 2016  1:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17148','5569040647','350786','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5569040647
folio:350786
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 15 2016  1:04PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17150','5548676446','63039','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5548676446
folio:63039
monto:50



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Sep 17 2016 10:47AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17152','9621719272','178794','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:9621719272
folio:178794
monto:50



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Sep 17 2016  2:59PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17153','5514381152','002430','Movistar','60','61.00','1','resultado:recarga exitosa
teléfono:5514381152
folio:002430
monto:60



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 19 2016 11:19AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17154','5574351271','594275','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5574351271
folio:594275
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 19 2016 12:12PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17155','5575477821','aaanjt','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:aaanjt
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 19 2016  1:18PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17156','5572727712','065333','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:065333
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 20 2016  8:42AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17157','5562282484','Error','Telcel','50','51.00','0','error en recarga:99 - rechazo tabla de transacciones llena - fi:88392708','Sep 21 2016  4:30PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17158','2281172239','786328','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:786328
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 21 2016  4:31PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17175','5522768591','Error','Unefon','50','51.00','0','error en recarga: referencia no valida / revisar operador','Sep 30 2016  4:50PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17176','5522768591','Error','Unefon','50','51.00','0','error en recarga: referencia no valida / revisar operador','Sep 30 2016  4:52PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17181','2281172239','592373','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:592373
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct  4 2016  2:46PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18182','5518602325','aaagfb','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5518602325
folio:aaagfb
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Oct  8 2016  1:21PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18183','5514317322','575782','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5514317322
folio:575782
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 10 2016  2:08PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18185','5564112549','050359','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5564112549
folio:050359
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 12 2016  2:28PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '8069','5564173305','436015','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5564173305
folio:436015
monto:50

realizar nueva recarga','Jun 20 2016  4:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11111','5546832821','483943','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:483943
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 14 2016  8:51AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12137','5563686355','774770','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5563686355
folio:774770
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  1 2016  5:30PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17151','5510928175','540370','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:540370
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Sep 17 2016  2:21PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17164','5574140137','673609','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5574140137
folio:673609
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 26 2016  3:55PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17168','9621719272','561140','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:9621719272
folio:561140



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 28 2016 11:15AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17169','9512396545','263964','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:9512396545
folio:263964



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 28 2016 12:08PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17170','5512293375','771759','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512293375
folio:771759
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 28 2016  2:54PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17171','5573959302','675288','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5573959302
folio:675288
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 28 2016  6:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17178','5511371228','598107','Telcel','150','151.00','1','resultado:recarga exitosa
teléfono:5511371228
folio:598107
monto:150



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 30 2016  7:49PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17179','5572778687','232008','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572778687
folio:232008
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct  3 2016 11:22AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17180','5514317322','43827','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5514317322
folio:43827
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct  3 2016  4:52PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17183','5546832821','492896','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:492896
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct  5 2016  3:19PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17185','5547034406','150361','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5547034406
folio:150361
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct  6 2016 12:14PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18181','5518184727','813284','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5518184727
folio:813284
monto:30



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Oct  8 2016  1:10PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18184','5564634817','650816','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5564634817
folio:650816
monto:30



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 12 2016  1:50PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18188','5574140137','154982','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5574140137
folio:154982
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 18 2016 11:27AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18190','2281172239','451578','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:451578
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 18 2016  4:13PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18197','7491082432','aabenw','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:7491082432
folio:aabenw
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 19 2016  7:07PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18198','5548478438','aaablf','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5548478438
folio:aaablf
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 20 2016  8:54AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18209','5512100061','459843','Unefon','20','21.00','1','resultado:recarga exitosa
teléfono:5512100061
folio:459843
monto:20



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Nov  5 2016  9:52AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18210','5542779921','aaanfs','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5542779921
folio:aaanfs
monto:100



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Nov  5 2016 11:01AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9068','5512404104','383562','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:383562
monto:50

realizar nueva recarga','Jun 21 2016 11:59AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9070','5561514770','002968','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5561514770
folio:002968
monto:50

realizar nueva recarga','Jun 21 2016 12:24PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9101','5512404104','912422','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:912422
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  4 2016 11:53AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12108','5523979371','937792','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5523979371
folio:937792
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Jul 16 2016  2:47PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13132','5532389637','936157','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5532389637
folio:936157
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug  8 2016  4:37PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13135','5518597919','aaaawu','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:aaaawu
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 10 2016  8:21AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13143','5532922532','996649','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5532922532
folio:996649
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 16 2016  2:31PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13145','5542610393','Error','Movistar','10','11.00','0','su sesión ha expirado, por favor inicie sesión aquí','Aug 17 2016  2:33PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13146','5542610393','605194','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5542610393
folio:605194
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 17 2016  2:34PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17163','2821021122','815809','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:2821021122
folio:815809
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 24 2016  1:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17165','5542242858','060920','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542242858
folio:060920
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 27 2016 10:59AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17166','5575466392','aaafgr','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575466392
folio:aaafgr
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 27 2016 11:21AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17172','5523172528','250458','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5523172528
folio:250458



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 29 2016 11:55AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17177','5538566029','aabfei','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:aabfei
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 30 2016  5:22PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17184','5537986147','674655','Movistar','30','31.00','1','resultado:recarga exitosa
teléfono:5537986147
folio:674655
monto:30



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Oct  6 2016  8:31AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18186','5567638312','082489','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5567638312
folio:082489
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 13 2016  8:31AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18192','5518597919','191584','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:191584
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 18 2016  4:39PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18199','5572727712','596636','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:596636
monto:10



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 20 2016  9:37AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18200','5568963102','669293','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5568963102
folio:669293
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 20 2016 11:31AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18203','5575491475','767650','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5575491475
folio:767650
monto:100



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 29 2016 11:26AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18205','5546832821','900194','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:900194
monto:10



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Nov  1 2016  7:26AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18206','5546832821','53232','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5546832821
folio:53232
monto:10



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Nov  1 2016 11:12AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9080','5591018233','683259','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5591018233
folio:683259
monto:50

realizar nueva recarga','Jun 25 2016  2:05PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '10103','5518597919','940906','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:940906
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul  7 2016  6:30PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12114','5572665006','39472576','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5572665006
folio:39472576
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 20 2016  5:42PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12115','5529297607','102909','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5529297607
folio:102909
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 20 2016  7:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12130','5510941353','30031','Movistar','200','201.00','1','resultado:recarga exitosa
teléfono:5510941353
folio:30031
monto:200



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 28 2016  2:50PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13128','5518597919','aabang','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:aabang
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug  4 2016  5:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13136','2281172239','288728','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:288728
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 10 2016  3:06PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17159','5562282484','925161','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5562282484
folio:925161
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 21 2016  4:34PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17160','5538750407','727845','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5538750407
folio:727845
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 21 2016  6:09PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17161','5538566029','aaaaub','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:aaaaub
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 23 2016  8:41AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17162','5542610393','332536','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5542610393
folio:332536
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 23 2016 10:03AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17173','5512404104','050406','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5512404104
folio:050406



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Sep 29 2016 12:57PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17174','7491082432','715046','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:7491082432
folio:715046
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 29 2016  5:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17186','5585325764','737083','Unefon','100','101.00','1','resultado:recarga exitosa
teléfono:5585325764
folio:737083
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct  7 2016  9:36AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17187','5572727712','30647','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5572727712
folio:30647
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct  7 2016 10:23AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18189','5538566029','054871','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5538566029
folio:054871
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 18 2016  2:59PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18191','5575477821','180777','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:180777
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 18 2016  4:14PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18204','5575518350','338417','Telcel','100','101.00','1','resultado:recarga exitosa
teléfono:5575518350
folio:338417
monto:100



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 31 2016  9:54AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18207','5560605253','372564','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5560605253
folio:372564
monto:20



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Nov  1 2016  2:46PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18208','5547034406','227970','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5547034406
folio:227970
monto:10



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Nov  4 2016  4:12PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18211','5527105668','618216','Telcel','20','21.00','1','resultado:recarga exitosa
teléfono:5527105668
folio:618216
monto:20



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Nov  5 2016 11:26AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '9100','5540921741','395097','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5540921741
folio:395097
monto:30

realizar nueva recarga','Jul  1 2016  5:41PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11109','5523197583','041781','Telcel','30','31.00','1','resultado:recarga exitosa
teléfono:5523197583
folio:041781
monto:30



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 13 2016  2:08PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '11110','5542242858','897558','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5542242858
folio:897558
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y despu?comprar un paquete para activarlo. 
realizar nueva recarga','Jul 13 2016  3:18PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12109','5575477821','635619','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:635619
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 18 2016  9:32AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18193','5535331475','453838','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:5535331475
folio:453838
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 18 2016  4:52PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18201','5575466392','920243','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575466392
folio:920243
monto:100



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Oct 22 2016  2:31PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18202','9621719272','776292','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:9621719272
folio:776292
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 27 2016  2:20PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12127','5533135792','684801','Movistar','10','11.00','1','resultado:recarga exitosa
teléfono:5533135792
folio:684801
monto:10



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 27 2016  1:53PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '12132','5510928175','589331','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:589331
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Jul 29 2016  5:14PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '14151','5538750407','706151','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5538750407
folio:706151
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Aug 27 2016  3:05PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18187','5572670324','aaahbm','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5572670324
folio:aaahbm
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 13 2016 12:06PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13144','5575486910','925827','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5575486910
folio:925827
monto:10



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Aug 17 2016  1:26PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13149','7491082432','40737795','Movistar','50','51.00','1','resultado:recarga exitosa
teléfono:7491082432
folio:40737795
monto:50



 para consultar dudas sobre recargas debe marcar al *611 


realizar nueva recarga','Aug 20 2016  9:02AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13154','2281172239','061886','Unefon','50','51.00','1','resultado:recarga exitosa
teléfono:2281172239
folio:061886
monto:50



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 23 2016  2:02PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '13156','5575477821','40905323','Movistar','100','101.00','1','resultado:recarga exitosa
teléfono:5575477821
folio:40905323
monto:100



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Aug 24 2016  9:09AM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '15150','5520581751','918982','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5520581751
folio:918982
monto:50



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Sep  1 2016  5:30PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18194','5532677293','686887','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5532677293
folio:686887
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct 19 2016  2:17PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18195','5513524328','501038','Unefon','200','201.00','1','resultado:recarga exitosa
teléfono:5513524328
folio:501038
monto:200



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 19 2016  3:03PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18196','5510928175','506980','Unefon','30','31.00','1','resultado:recarga exitosa
teléfono:5510928175
folio:506980
monto:30



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Oct 19 2016  4:47PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17167','5518597919','aaatpn','Movistar','20','21.00','1','resultado:recarga exitosa
teléfono:5518597919
folio:aaatpn
monto:20



para consultar dudas sobre recargas debe marcar al *611 

realizar nueva recarga','Sep 27 2016  5:16PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '17182','5539703375','221141','Telcel','50','51.00','1','resultado:recarga exitosa
teléfono:5539703375
folio:221141
monto:50



para consultar dudas sobre recargas debe marcar al *264 
para consultar dudas de paquetes debe marcar al *135#. 

nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 
realizar nueva recarga','Oct  5 2016 12:26PM')
INSERT INTO [dbo].[telephoneRecharge]([id],[phone],[folio],[companyName],[plan],[amount],[successful],[message],[createDate]) Values( '18212','5561514770','77625','Telcel','10','11.00','1','resultado:recarga exitosa
teléfono:5561514770
folio:77625
monto:10



 para consultar dudas sobre recargas debe marcar al *264 
 para consultar dudas de paquetes debe marcar al *135#. 

 nota: para los chips nuevos, es necesario primero hacer una recarga normal de $100.00, y después comprar un paquete para activarlo. 

realizar nueva recarga','Nov  6 2016  6:51AM')
