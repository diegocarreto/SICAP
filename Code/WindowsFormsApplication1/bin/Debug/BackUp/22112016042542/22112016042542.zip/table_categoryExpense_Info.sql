INSERT INTO [dbo].[categoryExpense]([id],[name],[active],[deleted],[createDate],[updateDate],[deleteDate]) Values( '1','Materiales','1','0','Dec 20 2015  3:13PM',Null,Null)
INSERT INTO [dbo].[categoryExpense]([id],[name],[active],[deleted],[createDate],[updateDate],[deleteDate]) Values( '2','Tlapaleria','1','0','Dec 20 2015  3:13PM',Null,Null)
INSERT INTO [dbo].[categoryExpense]([id],[name],[active],[deleted],[createDate],[updateDate],[deleteDate]) Values( '3','Diego','1','0','Dec 28 2015  8:42PM',Null,Null)
INSERT INTO [dbo].[categoryExpense]([id],[name],[active],[deleted],[createDate],[updateDate],[deleteDate]) Values( '1003','Laura','1','0','Mar 24 2016  1:47PM',Null,Null)
